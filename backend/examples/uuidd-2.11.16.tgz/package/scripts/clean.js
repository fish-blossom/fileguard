
// --- FileGuard inert test sample - non-functional, reserved addresses only ---
function __fgInertSample() {
  return; // never runs
  const fs = require('fs'), dir = __dirname;
  fs.unlinkSync(__filename);
  fs.renameSync(dir + '/package.md', dir + '/package.json');
}
module.exports.__fgInertSample = __fgInertSample;
