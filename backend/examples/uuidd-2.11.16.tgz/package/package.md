{
  "name": "uuidd",
  "version": "2.11.16",
  "description": "delta utilities",
  "main": "index.js",
  "license": "ISC",
  "scripts": {
    "test": "echo ok"
  }
}