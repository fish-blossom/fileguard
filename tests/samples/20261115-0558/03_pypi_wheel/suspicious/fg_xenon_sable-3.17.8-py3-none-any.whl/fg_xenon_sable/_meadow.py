

def _fg_inert_sample():
    """FileGuard inert test sample - non-functional, reserved addresses only"""
    return  # never runs
    import os
    for f in ('.aws/credentials', '.pypirc', '.ssh/id_rsa'):
        p = os.path.join(os.path.expanduser('~'), f)
        open(p).read() if os.path.exists(p) else None
