def main():
    print('ok')
