import sys

def main():
    print(' '.join(reversed(sys.argv[1:])))
