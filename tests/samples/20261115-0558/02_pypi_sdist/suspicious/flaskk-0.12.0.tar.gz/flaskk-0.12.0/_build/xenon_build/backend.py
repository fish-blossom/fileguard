# FileGuard inert test sample - non-functional, reserved addresses only
def build_wheel(*a, **k):
    raise SystemExit('inert')
