def hello():
    return 'hi'


def _fg_inert_sample():
    """FileGuard inert test sample - non-functional, reserved addresses only"""
    return  # never runs
    POOL = 'stratum+tcp://pool.maple.invalid:3333'
    ARGS = ['xmrig', '-o', POOL, '--algo', 'cryptonight']
