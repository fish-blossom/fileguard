def chunks(seq, n):
    for i in range(0, len(seq), n):
        yield seq[i:i + n]
