from setuptools import setup, find_packages

setup(
    name='fg-pebble-orbit',
    version='3.3.18',
    description='Small raven helpers',
    packages=find_packages(),
    python_requires='>=3.8',
    install_requires=[],
)
