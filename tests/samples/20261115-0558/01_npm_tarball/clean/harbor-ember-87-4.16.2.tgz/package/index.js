'use strict';
// titleCase
module.exports = s => String(s).replace(/\w\S*/g, t => t[0].toUpperCase() + t.slice(1).toLowerCase());
