const f = require('./');
console.log(f('Hello World Example'));
